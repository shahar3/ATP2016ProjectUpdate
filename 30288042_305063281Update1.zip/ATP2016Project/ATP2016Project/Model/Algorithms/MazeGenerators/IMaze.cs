﻿namespace ATP2016Project.Model.Algorithms.MazeGenerators
{
    interface IMaze
    {
        void print();
    }
}
